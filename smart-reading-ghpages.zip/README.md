# منصة القراءة الذكية (جاهزة لـ GitHub Pages)

- **index.html**: الواجهة والتصميم كما هو.
- **script.js**: منطق التطبيق مع إضافة تشغيل ملفات MP3 + بديل TTS.
- **audio/**: ملفات الصوت الجاهزة.

## ملفات الصوت الموجودة (9):
- luvvoice.com-20250829-FYw1fI.mp3
- luvvoice.com-20250829-zYDQwp.mp3
- luvvoice.com-20250829-Wu9epC.mp3
- luvvoice.com-20250829-Nk4JdQ.mp3
- luvvoice.com-20250829-Nk4JdQ.mp3
- luvvoice.com-20250829-GbpwvG.mp3
- luvvoice.com-20250829-nngwau.mp3
- luvvoice.com-20250829-lDPtdq.mp3
- luvvoice.com-20250829-lN0xMU.mp3

> يمكن تعديل ربط النصوص بالملفات داخل `script.js` في الكائن `audioMap`.
